#include<stdio.h>
#include<windows.h>
#include<string.h>
#include<math.h>
#include <time.h>
struct Fristdate
{
    int d,m,y,p;
};
struct location
{
    char location[15];
    char name[10];
    char s1;
    char response;
    char number[12];
};

void loading()
{
    int i,j=2;
    while(j>0)
    {

        for(i=1; i<10; i++)
        {
            COORD c;
            c.X=i;
            c.Y=1;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
            printf("-");
            fflush(stdin);
            Sleep(100);
        }
        Sleep(200);
        system("cls");
        for(i=10; i>1; i--)
        {
            COORD c;
            c.X=i;
            c.Y=1;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
            printf("-");
            fflush(stdin);
            Sleep(100);
        }
        system("cls");
        j--;
    }
}

void SignIN()
{
    char name[10];
    char location[10];
    char number[12];
    char group;
    char r;
    char pass[5];
    int i,l,q=10;
    FILE *fa;
    printf("Enter Your Name : \n");
    scanf(" %s",name);
    fa=fopen("name.txt","a");
    fprintf(fa,"\n%s",name);
    fclose(fa);

    printf("\nEnter Your Password : \n");
    scanf(" %s",pass);
    fa=fopen("pass.txt","a");
    fprintf(fa,"\n%s",pass);
    fclose(fa);

    printf("\nEnter Your Location : \n");
    scanf(" %s",location);
    fa=fopen("location.txt","a");
    fprintf(fa,"\n%s",location);
    fclose(fa);

    printf("\nEnter Your Number : \n");
    scanf(" %s",number);
    fa=fopen("number.txt","a");
    fprintf(fa,"\n%s",number);
    fclose(fa);

    printf("\nEnter Your Blood Group : \n");
    scanf(" %c",&group);
    fa=fopen("group.txt","a");
    fprintf(fa,"\n%c",group);
    fclose(fa);

    printf("\nDo You Want To Show Your Number :\n");
    scanf(" %c",&r);

    fa=fopen("Response.txt","a");
    fprintf(fa,"\n%c",r);
    fclose(fa);

    system("cls");
    void loading();
    printf("Your Data Has Enlisted..");
}
struct check
{
    char name[10];
    char pass[5];
};
double pd(double pl,double plo,double c,double d)
{
    double x=sqrt(((pl-c)*(pl-c))+((plo-d)*(plo-d)));
    return x;
}

void sorting(double arr[1000],int size)
{
    int j,i;
    double min,k;
    for(i=0; i<size; i++)
    {
        for(j=i; j<size; j++)
        {
            if(arr[i]>arr[j])
            {
                k=arr[i];
                arr[i]=arr[j];
                arr[j]=k;
            }
        }
    }
}



int main()
{
    system("color 5f");
    COORD c;
    c.X=10;
    c.Y=1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
    printf("Welcome To Blood Chain\n\n");
    printf("\tYou Are A ");
    printf("  1.User");
    printf("  2.Donar\n\n");
    int i,j,k,l,p,o,x,y,md,cd,e,pl,lp,w,id,u;
    j=3;k=0;
    char s;
    char ps[11];
    char UserId[6];
    char Password[5];
    struct Fristdate arr[10];
    struct check arr1[10];
    struct location arr2[10];
    double distance,latitude,longitude;
    pl=0;
    double la[10];
    double lo[10];
    scanf("%d",&i);
    system("cls");
    int UserCode_arr[10];
    FILE *fa;
    fa=fopen("UserCode.txt","r");
    for(w=0; w<13; w++)
    {
        fscanf(fa," %d",&UserCode_arr[w]);
    }
    fclose(fa);
    if(i==1)
    {
        printf("\nWhat Is The Group Of Blood You Need\n\n ");
        scanf(" %c",&s);
        printf("\nWhat Is Your Location \n\n");
        scanf(" %s",ps);

fa=fopen("latitude.txt","r");
    for(w=0; w<10; w++)
    {
        fscanf(fa,"%lf",&la[w]);
    }
    fclose(fa);


    fa=fopen("longitude.txt","r");
    for(w=0; w<10; w++)
    {
        fscanf(fa,"%lf",&lo[w]);
    }
    fclose(fa);

    fa=fopen("location.txt","r");
    for(w=0; w<10; w++)
    {
        fscanf(fa," %s",arr2[w].location);
    }
    fclose(fa);
    //////////////////////////////////////
    fa=fopen("Name.txt","r");
    for(w=0;w<10;w++)
    {
        fscanf(fa," %s",arr2[w].name);
    }
    fclose(fa);
    fa=fopen("Group.txt","r");
    for(w=0; w<10; w++)
    {
        fscanf(fa," %c",&arr2[w].s1);
    }
    fclose(fa);

    fa=fopen("Response.txt","r");
    for(w=0; w<10; w++)
    {
        //printf("%s\n",arr[i].name);
        fscanf(fa," %c",&arr2[w].response);
    }
    fclose(fa);
    fa=fopen("Number.txt","r");
    for(w=0; w<10; w++)
    {
        fscanf(fa,"%s",arr2[w].number);
    }
    fclose(fa);


/////////////////////////////////////////////////
    for(w=0; w<10; w++)
    {
        if(strcmp(ps,arr2[w].location)==0)
        {
            latitude=la[w];
            longitude=lo[w];
            break;
        }
    }


    double clalo[10];
    for(w=0; w<10; w++)
    {
        clalo[w]=pd(latitude,longitude,la[w],lo[w]);
    }
    double clalo1[10];
    for(w=0; w<10; w++)
    {
        clalo1[w]=clalo[w];
    }

    sorting(clalo1,10);
    for(w=0; w<10; w++)
    {
        for(j=0; j<10; j++)
        {
            if(clalo1[w]==clalo[j])//246
            {
                if(arr2[w].s1==s)
                {
                    printf("\n %s\n",arr2[w].name);
                    printf(" %s\n",arr2[w].location);
                    //printf(" %d\n",UserCode_arr[w]);
                    if(arr2[w].response=='y'){printf(" %s\n\n",arr2[w].number);}
                }
                break;
            }
        }
    }


    }
    if(i==2)
    {
        printf("\n\tYou Have To Login To View The Information\n\n");
        while(1)
        {
            printf("\n\nSign UP[1]\n");
            printf("\n\nSign IN[2]\n ");
            scanf("%d",&o);
            if(o==1)
            {
                SignIN();
            }
            if(o==2)
            {
                break;
            }
        }
        fa=fopen("name.txt","r");
        for(l=0; l<10; l++)
        {
            fscanf(fa,"%s",arr1[l].name);
        }
        fclose(fa);

        fa=fopen("pass.txt","r");
        for(l=0; l<10; l++)
        {
            fscanf(fa,"%s",arr1[l].pass);
        }
        fclose(fa);

        while(j>0)
        {
            printf("\nEnter your User id:\n");
            scanf(" %s",UserId);
            printf("Enter your Password\n");
            scanf(" %s",Password);
            for(i=0; i<10; i++)
            {
                x=strcmp(arr1[i].name,UserId);
                y=strcmp(arr1[i].pass,Password);
                if(x==0 && y==0)
                {
                    printf("Successfully logged in\n\n");
                    i=l;
                    k=1;
                    break;
                }
            }
            if(k==1)
            {
                system("cls");
                break;
            }

            if(x!=0 || y!=0)
            {
                system("cls");
                printf("\nInvalid user name or password.Try Again!\n");
                j--;
            }
        }
        if(k==1)
        {
            printf("UPDATE YOUR INFORMATION [1]\n");
            scanf("%d",&u);
            if(u==1){
                printf("Which Data You Want TO UPDATE..\n\nPhone Number [1]\n\nLocation [2]\n\nPhone NUmber Privacy [3]\n\nYour Laste Blood Donate Date [4] \n");
    scanf("%d",&u);
    printf("Please Enter Your User Code : \n");
    scanf("%d",&id);
    fa=fopen("UserCode.txt","r");
    for(w=0; w<13; w++)
    {
        fscanf(fa," %d",&UserCode_arr[w]);
    }
    fclose(fa);
    if(u==1)
    {
        fa=fopen("Number.txt","r");
        for(w=0; w<10; w++)
        {
            fscanf(fa," %s",arr2[w].number);
        }
        fclose(fa);
        for(w=0; w<13; w++)
        {
            if(id==UserCode_arr[w])
            {
                printf("Please Enter Your Number : \n");
                scanf(" %s",arr2[w].number);
                break;
            }
        }
        fa=fopen("Number.txt","w");
        for(w=0; w<10; w++)
        {
            fprintf(fa,"%s\n",arr2[w].number);
        }
        fclose(fa);
    }
    if(u==2)
    {
        fa=fopen("location.txt","r");
        for(w=0; w<10; w++)
        {
            fscanf(fa," %s",arr2[w].location);
        }
        fclose(fa);
        for(w=0; w<13; w++)
        {
            if(id==UserCode_arr[w])
            {
                printf("Please Enter Your Location : \n");
                scanf(" %s",arr2[w].location);
                break;
            }
        }
        fa=fopen("location.txt","w");
        for(w=0; w<10; w++)
        {
            fprintf(fa,"%s\n",arr2[w].location);
        }
        fclose(fa);
    }
    if(u==3)
    {
        fa=fopen("Response.txt","r");
        for(w=0; w<10; w++)
        {
            fscanf(fa," %c",&arr2[w].response);
        }
        fclose(fa);
        for(w=0; w<13; w++)
        {
            if(id==UserCode_arr[w])
            {
                printf("Do You Want To Show Your Number : \n");
                scanf(" %c",&arr2[w].response);
                break;
            }
        }
        fa=fopen("Response.txt","w");
        for(w=0; w<10; w++)
        {
            fprintf(fa,"%c\n",arr2[w].response);
        }
        fclose(fa);
    }
    if(u==4)
    {
        struct Fristdate arr[10];
        fa=fopen("date.txt","r");
        for(w=0; w<10; w++)
        {
            fscanf(fa," %d",&arr[w].d);
        }
        fclose(fa);
        fa=fopen("month.txt","r");
        for(w=0; w<10; w++)
        {
            fscanf(fa," %d",&arr[w].m);
        }
        fclose(fa);
        fa=fopen("year.txt","r");
        for(w=0; w<10; w++)
        {
            fscanf(fa," %d",&arr[w].y);
        }
        fclose(fa);
        for(w=0; w<10; w++)
        {
            if(id==UserCode_arr[w])
            {
                printf("What Was Your Last Date Of Blood Donate : \n");
                scanf(" %d",&arr[w].d);
                printf("\nWhat Was Your Last Month Of Blood Donate : \n");
                scanf(" %d",&arr[w].m);
                printf("\nWhat Was Your Last Year Of Blood Donate : \n");
                scanf(" %d",&arr[w].y);
                break;
            }
        }
        fa=fopen("date.txt","w");
        for(w=0; w<10; w++)
        {
            fprintf(fa,"%d\n",arr[w].d);
        }
        fclose(fa);
        fa=fopen("month.txt","w");
        for(w=0; w<10; w++)
        {
            fprintf(fa,"%d\n",arr[w].m);
        }
        fclose(fa);
        fa=fopen("year.txt","w");
        for(w=0; w<10; w++)
        {
            fprintf(fa,"%d\n",arr[w].y);
        }
        fclose(fa);

    }
            }
            //FILE *fa;
            fa=fopen("date.txt","r");
            for(l=0; l<10; l++)
            {
                fscanf(fa,"%d",&arr[l].d);
            }
            fclose(fa);

            fa=fopen("month.txt","r");
            for(l=0; l<10; l++)
            {
                fscanf(fa,"%d",&arr[l].m);
            }
            fclose(fa);

            fa=fopen("year.txt","r");
            for(l=0; l<10; l++)
            {
                fscanf(fa,"%d",&arr[l].y);
            }
            fclose(fa);
            fa=fopen("checkupdate","r");
            for(l=0; l<10; l++)
            {
                fscanf(fa,"%d",&arr[l].p);
            }
            fclose(fa);

            time_t t = time(NULL);
            struct tm tm = *localtime(&t);
            int cd,cm,cy,md,dd;//cd=current date,md=month difference in days
            cd=tm.tm_mday;
            cm=tm.tm_mon+1;
            cy=tm.tm_year+1900;

            //checking
            if(cy==arr[i].y)
            {
                if(cm==arr[i].m)
                {
                    COORD c;
                    c.X=20;
                    c.Y=10;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                    printf("\t\tWarrning !!!!\n\n");
                    printf("\t\tYou Can't Donate Blood\n");
                }
                else
                {
                    md=(abs(cm-arr[i].m))*30;
                    dd=abs(cd-arr[i].d);
                    if(md+cd>=70)
                    {
                        COORD c;
                        c.X=20;
                        c.Y=10;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                        printf("\n\nYou Are Eligable To Donate Your Bloode\n\n");
                    }
                    else
                    {
                        COORD c;
                        c.X=25;
                        c.Y=10;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_GREEN|BACKGROUND_INTENSITY);
                        printf("Warrning !!!!\n");
                        c.X=20;
                        c.Y=12;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                        printf("\tYou Can't Donate Blood\n\n");
                    }
                }
            }
            else
            {

                if(cy==arr[i].p)
                {
                    COORD c;
                    c.X=20;
                    c.Y=5;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                    printf("You Are Eligable To Donate Your Bloode\n\n");
                }
                else
                {
                    COORD c;
                    c.X=20;
                    c.Y=5;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                    printf("You Are Eligable To Donate Your Bloode\n\n");
                    c.X=35;
                    c.Y=10;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                    printf("Warrning !!!!\n");
                    c.X=20;
                    c.Y=13;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
                    printf("Please ReCheckup your Blood Health\n\n\n");
                }

            }

        }

    }
}



